# License information for URW Core 35 Fonts, Version 2.00

The fonts and related files in this directory are distributed under the following licenses:

* [GNU Affero General Public License, Version 3](./COPYING) with an [exemption](./LICENSE)
* [The LaTeX Project Public License, Version 1.3c](./LICENSE.LPPL)
* [SIL Open Font License, Version 1.1](./LICENSE.OFL)

Copyright 2013,2014,2015 by (URW)++ Design & Development

